<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
   <meta name="description" content="" />
   <meta name="author" content="" />
   <title>Add Purchase</title>
   <?php
   include 'include/head.php';
   ?>
</head>

<body id="page-top">
   <!-- Page Wrapper -->
   <div id="wrapper">
      <!-- Sidebar start -->
      <?php
      include 'include/sidebar.php';
      ?>
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
         <!-- Main Content -->
         <div id="content">
            <!-- Topbar -->
            <?php
            include 'include/header.php';
            ?>
            <!-- Topbar -->
            <!-- 1st container start -->
            <?php
            include 'include/tabs.php';
            ?>

            <div class="container-fluid bg-white  border-0 ">
               <!-- 1st row start -->
               <div class="row no-gutters my-2">
                  <div class="col-md-12">
                     <p class="text-dark font-weight-bold">Dashboard > Add Purchase</p>
                     <ul class="d-flex justify-content-around " style="list-style: none;font-family: Roboto;">
                        <li> <button class="btn tabcolor text-white">ALL</button> </li>
                        <li> <button class="btn tab2 text-white">Last Month</button> </li>
                        <li> <button class="btn tab3 text-white">3 Month</button> </li>
                        <li> <button class="btn tab4 text-white">1 Year</button> </li>
                        <li> <button class="btn tab5 text-white text-sm">DATES FROM-TO</button> </li>
                        <li> <button id="addpurchase" class="btn text-white rounded-pill tab6" style="height: auto;">Add
                              Purchase</button> </li>
                     </ul>
                  </div>
               </div>
               <!-- 1st Row end -->
               <!-- 3rd Row start -->
               <div class="row addpurchase card p-2 mb-2 bg-light border-0">
                  <div class="col-md-12">
                     <form class="my-1">
                        <div class="form-row">
                           <div class="form-group col-2">
                              <label>Date </label>
                              <input type="date" class="form-control form-control-sm" placeholder="">
                           </div>
                           <div class="form-group col-2">
                              <label> Purchase ID</label>
                              <input type="text" class="form-control form-control-sm" placeholder="">
                           </div>
                           <div class="form-group col-2">
                              <label>Vendor Name</label>
                              <input type="text" class="form-control form-control-sm" placeholder="">
                           </div>
                           <div class="form-group col-1">
                              <label>Quantity </label>
                              <input type="number" class="form-control form-control-sm" placeholder="">
                           </div>
                           <div class="form-group col-1">
                              <label>Completed </label>
                              <input type="number" class="form-control form-control-sm" placeholder="">
                           </div>
                           <div class="form-group col-1">
                              <label>Price </label>
                              <input type="number" class="form-control form-control-sm" placeholder="">
                           </div>
                           <div class="form-group col-2">
                              <label> NOTES</label>
                              <input type="text" class="form-control form-control-sm" placeholder="">
                           </div>
                           <div class="form-group col-1 text-right">
                              <label class="invisible"> Save button </label>
                              <button type="submit" class="btn btn-primary btn-sm">Save</button>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
               <!-- 3rd Row end -->
               <!-- 2nd Row start -->
               <div class="row">
                  <div class="col-md-12">
                     <div class="table-responsive">
                        <table class="table align-items-center table-flush table-hover" id="sampleTable">
                           <thead class="thead-light">
                              <tr>
                                 <th> Date</th>
                                 <th> Purchase ID</th>
                                 <th>Vendor Name </th>
                                 <th>Quantity </th>
                                 <th> Completed</th>
                                 <th>Price </th>
                                 <th> NOTES</th>
                              </tr>
                           </thead>
                           <tbody>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                              <tr>
                                 <td> 12-12-2022 </td>
                                 <td>dfghjkl;52 </td>
                                 <td> Hery Berlin </td>
                                 <td>545 </td>
                                 <td>545 </td>
                                 <td>76578 </td>
                                 <td>some notes will be here </td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
               <!-- 2nd Row end -->
            </div>
            <!-- 1st container-fluid -->
         </div>
         <!-- End of Content Wrapper -->
      </div>
      <!-- End of Page Wrapper -->
      <!-- Scroll to Top Button-->
      <a class="scroll-to-top rounded" href="#page-top">
         <i class="fas fa-angle-up"></i>
      </a>
      <?php
      include 'include/footer.php';
      ?>
</body>

</html>