<?php
$connection = mysqli_connect("localhost:3306", "root", "", "pc");
if (mysqli_connect_error()) {
    echo "<script> alert('Cannot Connect to Database');</script>";
    exit;
}

?>