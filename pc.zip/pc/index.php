<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
   <meta name="description" content="" />
   <meta name="author" content="" />
   <title>Dashboard</title>
   <!-- Custom fonts for this template-->
   <?php
   include 'include/head.php';
   ?>

</head>

<body id="page-top">
   <!-- Page Wrapper -->
   <div id="wrapper">
      <!-- Sidebar start -->
      <?php
      include 'include/sidebar.php';
      ?>
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
         <!-- Main Content -->
         <div id="content">
            <!-- Header -->
            <?php
            include 'include/header.php';
            ?>
            <!-- Tab  -->
            <?php
            include 'include/tabs.php'
               ?>
            <!-- 2nd container start-->
            <div class="container-fluid ">
               <!-- 1st row start -->
               <div class="row no-gutters">
                  <div class="col-md-6">
                     <div class="card carddd h-10">
                        <div class="card-body">
                           <div class="d-flex justify-content-between">
                              <div class="">
                                 <!-- <i class="fas fa-ellipsis-v"></i> -->
                                 <span>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="9" height="16" viewBox="0 0 9 16"
                                       fill="none">
                                       <path d="M3.53003 12.32H0.130005V15.19H3.53003V12.32Z" fill="#A7A7AC" />
                                       <path d="M8.29999 12.32H4.90002V15.19H8.29999V12.32Z" fill="#A7A7AC" />
                                       <path d="M3.56 8.34003H0.159973V11.21H3.56V8.34003Z" fill="#A7A7AC" />
                                       <path d="M8.33002 8.34003H4.92999V11.21H8.33002V8.34003Z" fill="#A7A7AC" />
                                       <path d="M3.56 4.45001H0.159973V7.32001H3.56V4.45001Z" fill="#A7A7AC" />
                                       <path d="M8.34003 4.45001H4.94V7.32001H8.34003V4.45001Z" fill="#A7A7AC" />
                                       <path d="M3.53003 0.469971H0.130005V3.34003H3.53003V0.469971Z" fill="#A7A7AC" />
                                       <path d="M8.29999 0.469971H4.90002V3.34003H8.29999V0.469971Z" fill="#A7A7AC" />
                                    </svg>
                                 </span>
                                 <span class="fst-normal textcolor" style="font-family: Roboto;">
                                    Total Orders (New)
                                 </span>
                              </div>
                              <div class="">
                                 <i class="fas fa-cog"></i>
                              </div>
                           </div>
                           <hr />
                           <div class="chart-container">
                              <canvas id="doughnutChart"></canvas>
                              <!-- <div id="legend-container" class="legend-container"style="font-family: Roboto;"></div> -->
                              <div class="d-flex">
                                 <div class="">
                                    <table class="table customtable table2"
                                       style="font-family: Roboto; font-size:14px;">
                                       <tbody>
                                          <tr>
                                             <td width="80%" class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-danger dot">•</span>
                                                   <span class=""> Unalocated </span>
                                                </span>
                                             </td>
                                             <td width="20%" class=""> 60</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-info dot">•</span>
                                                   <span class=""> Workshop</span>
                                                </span>

                                             </td>
                                             <td class=""> 90</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-warning dot">•</span>
                                                   <span class=""> Cleaning</span>
                                                </span>

                                             </td>
                                             <td class=""> 20</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-success dot">•</span>
                                                   <span class=""> Packing </span>
                                                </span>

                                             </td>
                                             <td class=""> 50</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-success dot">•</span>
                                                   <span class=""> Dispatched </span>
                                                </span>

                                             </td>
                                             <td class=""> 30</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-success dot">•</span>
                                                   <span class=""> Pending </span>
                                                </span>

                                             </td>
                                             <td class=""> 60</td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                                 <div class="">
                                    <table class="table customtable table2"
                                       style="font-family: Roboto; font-size:14px;">
                                       <tbody>
                                          <tr>
                                             <td width="80%" class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-danger dot">•</span>
                                                   <span class=""> Ebay </span>
                                                </span>
                                             </td>
                                             <td width="20%" class=""> 4783</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-info dot">•</span>
                                                   <span class=""> Amazon</span>
                                                </span>

                                             </td>
                                             <td class=""> 76898</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-warning dot">•</span>
                                                   <span class=""> Website</span>
                                                </span>

                                             </td>
                                             <td class=""> 228</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-success dot">•</span>
                                                   <span class=""> Walk In </span>
                                                </span>

                                             </td>
                                             <td class=""> 56777</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-success dot">•</span>
                                                   <span class=""> Dropshipping </span>
                                                </span>

                                             </td>
                                             <td class=""> 56777</td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>

                              </div>
                           </div>


                        </div>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="card carddd h-10">
                        <div class="card-body">
                           <div class="d-flex justify-content-between">
                              <div class="">
                                 <!-- <i class="fas fa-ellipsis-v"></i> -->
                                 <span>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="9" height="16" viewBox="0 0 9 16"
                                       fill="none">
                                       <path d="M3.53003 12.32H0.130005V15.19H3.53003V12.32Z" fill="#A7A7AC" />
                                       <path d="M8.29999 12.32H4.90002V15.19H8.29999V12.32Z" fill="#A7A7AC" />
                                       <path d="M3.56 8.34003H0.159973V11.21H3.56V8.34003Z" fill="#A7A7AC" />
                                       <path d="M8.33002 8.34003H4.92999V11.21H8.33002V8.34003Z" fill="#A7A7AC" />
                                       <path d="M3.56 4.45001H0.159973V7.32001H3.56V4.45001Z" fill="#A7A7AC" />
                                       <path d="M8.34003 4.45001H4.94V7.32001H8.34003V4.45001Z" fill="#A7A7AC" />
                                       <path d="M3.53003 0.469971H0.130005V3.34003H3.53003V0.469971Z" fill="#A7A7AC" />
                                       <path d="M8.29999 0.469971H4.90002V3.34003H8.29999V0.469971Z" fill="#A7A7AC" />
                                    </svg>
                                 </span>
                                 <span class="fst-normal textcolor" style="font-family: Roboto;">
                                    Order History
                                 </span>
                              </div>
                              <div class="">
                                 <i class="fas fa-cog"></i>
                              </div>
                           </div>
                           <hr />
                           <div class="chart-container2">
                              <canvas id="doughnutChart2"></canvas>
                              <div class="all d-flex">
                                 <div id="legend-container2" class="legend-container2" style="font-family: Roboto;">
                                 </div>
                                 <div class="d-flex">
                                    <table class="table table2 customtable" style="font-family: Roboto;">
                                       <tbody>
                                          <tr>
                                             <td width="80%" class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-danger dot">•</span>
                                                   <span class=""> Ebay </span>
                                                </span>
                                             </td>
                                             <td width="20%" class=""> 50</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-info dot">•</span>
                                                   <span class=""> Amazon</span>
                                                </span>

                                             </td>
                                             <td class=""> 90</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-warning dot">•</span>
                                                   <span class=""> Website </span>
                                                </span>

                                             </td>
                                             <td class=""> 20</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-success dot">•</span>
                                                   <span class=""> Walk In</span>
                                                </span>

                                             </td>
                                             <td class=""> 50</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-info dot">•</span>
                                                   <span class=""> Dropshipping </span>
                                                </span>

                                             </td>
                                             <td class=""> 30</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-danger dot">•</span>
                                                   <span class=""> Return </span>
                                                </span>

                                             </td>
                                             <td class=""> 30</td>
                                          </tr>
                                       </tbody>
                                    </table>
                                    <table class="table table2 customtable" style="font-family: Roboto;">
                                       <tbody>
                                          <tr>
                                             <td width="80%" class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-danger dot">•</span>
                                                   <span class=""> Amount </span>
                                                </span>
                                             </td>
                                             <td width="20%" class=""> 0000</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-info dot">•</span>
                                                   <span class=""> Amount</span>
                                                </span>

                                             </td>
                                             <td class=""> 0000</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-warning dot">•</span>
                                                   <span class=""> Amount</span>
                                                </span>

                                             </td>
                                             <td class=""> 0000</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-success dot">•</span>
                                                   <span class=""> Amount </span>
                                                </span>

                                             </td>
                                             <td class=""> 0000</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-info dot">•</span>
                                                   <span class=""> Amount </span>
                                                </span>

                                             </td>
                                             <td class=""> 0000</td>
                                          </tr>
                                          <tr>
                                             <td class="text-left">
                                                <span class="d-flex">
                                                   <span class="text-danger dot">•</span>
                                                   <span class=""> Amount </span>
                                                </span>

                                             </td>
                                             <td class=""> 0000</td>
                                          </tr>
                                       </tbody>
                                    </table>

                                 </div>
                              </div>


                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- 1st Row end -->
               <!-- 2nd row start -->
               <div class="row no-gutters my-1 mx-1">
                  <div class="col-md-4">
                     <div class="card cardd h-100">
                        <div class="card-body">
                           <div class="d-flex justify-content-between">
                              <div class="">
                                 <!-- <i class="fas fa-ellipsis-v"></i> -->
                                 <span>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="9" height="16" viewBox="0 0 9 16"
                                       fill="none">
                                       <path d="M3.53003 12.32H0.130005V15.19H3.53003V12.32Z" fill="#A7A7AC" />
                                       <path d="M8.29999 12.32H4.90002V15.19H8.29999V12.32Z" fill="#A7A7AC" />
                                       <path d="M3.56 8.34003H0.159973V11.21H3.56V8.34003Z" fill="#A7A7AC" />
                                       <path d="M8.33002 8.34003H4.92999V11.21H8.33002V8.34003Z" fill="#A7A7AC" />
                                       <path d="M3.56 4.45001H0.159973V7.32001H3.56V4.45001Z" fill="#A7A7AC" />
                                       <path d="M8.34003 4.45001H4.94V7.32001H8.34003V4.45001Z" fill="#A7A7AC" />
                                       <path d="M3.53003 0.469971H0.130005V3.34003H3.53003V0.469971Z" fill="#A7A7AC" />
                                       <path d="M8.29999 0.469971H4.90002V3.34003H8.29999V0.469971Z" fill="#A7A7AC" />
                                    </svg>
                                 </span>
                                 <span class="fst-normal textcolor" style="font-family: Roboto;">
                                    Inventory ( 30 Days )
                                 </span>
                              </div>
                              <div class="">
                                 <i class="fas fa-cog"></i>
                              </div>
                           </div>
                           <hr class="hr" />
                           <div class="">
                              <table class="table " style="font-family: Roboto;">
                                 <tbody>
                                    <tr>
                                       <td width="80%" class="text-left">
                                          <span class="d-flex">
                                             <span class="text-danger dot">•</span>
                                             <span class=""> Purchase </span>
                                          </span>
                                       </td>
                                       <td width="20%" class=""> 4783</td>
                                    </tr>
                                    <tr>
                                       <td class="text-left">
                                          <span class="d-flex">
                                             <span class="text-info dot">•</span>
                                             <span class=""> Purchase Return</span>
                                          </span>

                                       </td>
                                       <td class=""> 76898</td>
                                    </tr>
                                    <tr>
                                       <td class="text-left">
                                          <span class="d-flex">
                                             <span class="text-warning dot">•</span>
                                             <span class=""> Sales </span>
                                          </span>

                                       </td>
                                       <td class=""> 228</td>
                                    </tr>
                                    <tr>
                                       <td class="text-left">
                                          <span class="d-flex">
                                             <span class="text-success dot">•</span>
                                             <span class=""> Sales Return </span>
                                          </span>

                                       </td>
                                       <td class=""> 56777</td>
                                    </tr>
                                 </tbody>
                              </table>

                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="card cardd h-100">
                        <div class="card-body">
                           <div class="d-flex justify-content-between">
                              <div class="">
                                 <!-- <i class="fas fa-ellipsis-v"></i> -->
                                 <span>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="9" height="16" viewBox="0 0 9 16"
                                       fill="none">
                                       <path d="M3.53003 12.32H0.130005V15.19H3.53003V12.32Z" fill="#A7A7AC" />
                                       <path d="M8.29999 12.32H4.90002V15.19H8.29999V12.32Z" fill="#A7A7AC" />
                                       <path d="M3.56 8.34003H0.159973V11.21H3.56V8.34003Z" fill="#A7A7AC" />
                                       <path d="M8.33002 8.34003H4.92999V11.21H8.33002V8.34003Z" fill="#A7A7AC" />
                                       <path d="M3.56 4.45001H0.159973V7.32001H3.56V4.45001Z" fill="#A7A7AC" />
                                       <path d="M8.34003 4.45001H4.94V7.32001H8.34003V4.45001Z" fill="#A7A7AC" />
                                       <path d="M3.53003 0.469971H0.130005V3.34003H3.53003V0.469971Z" fill="#A7A7AC" />
                                       <path d="M8.29999 0.469971H4.90002V3.34003H8.29999V0.469971Z" fill="#A7A7AC" />
                                    </svg>
                                 </span>
                                 <span class="fst-normal textcolor" style="font-family: Roboto;">
                                    Accounts ( 30 Days )
                                 </span>
                              </div>
                              <div class="">
                                 <i class="fas fa-cog"></i>
                              </div>
                           </div>
                           <hr />
                           <div class="d-flex justify-content-between accounttable">
                              <div class="">
                                 <table class="table " style="font-family: Roboto;">
                                    <tbody>
                                       <tr>
                                          <td class="text-left">
                                             <span class="d-flex">
                                                <span class="text-success dot">•</span>
                                                <span class=""> Total Sales </span>
                                             </span>

                                          </td>
                                          <td class=""> 4783</td>
                                       </tr>
                                       <tr>
                                          <td class="text-left">
                                             <span class="d-flex">
                                                <span class="text-primary dot">•</span>
                                                <span class=""> Cost of Sales </span>
                                             </span>

                                          </td>
                                          <td class=""> 76898</td>
                                       </tr>
                                       <tr>
                                          <td class="text-left">
                                             <span class="d-flex">
                                                <span class="text-info dot">•</span>
                                                <span class=""> ShippingCost </span>
                                             </span>

                                          </td>
                                          <td class=""> 228</td>
                                       </tr>
                                       <tr>
                                          <td class="text-left">
                                             <span class="d-flex">
                                                <span class="text-secondary dot">•</span>
                                                <span class=""> Ebay Sales </span>
                                             </span>

                                          </td>
                                          <td class=""> 56777</td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                              <div class="">
                                 <table class="table ">
                                    <tbody>
                                       <tr>
                                          <td class="text-left">
                                             <span class="d-flex">
                                                <span class="text-success dot">•</span>
                                                <span class=""> Local Sales </span>
                                             </span>

                                          </td>
                                          <td class=""> 4783</td>
                                       </tr>
                                       <tr>
                                          <td class="text-left">
                                             <span class="d-flex">
                                                <span class="text-secondary dot">•</span>
                                                <span class=""> Gross Profit </span>
                                             </span>

                                          </td>
                                          <td class=""> 76898</td>
                                       </tr>
                                       <tr>
                                          <td class="text-left">
                                             <span class="d-flex">
                                                <span class="text-warning dot">•</span>
                                                <span class=""> AmazonSales </span>
                                             </span>

                                          </td>
                                          <td class=""> 228</td>
                                       </tr>
                                       <tr>
                                          <td class="text-left">
                                             <span class="d-flex">
                                                <span class="text-success dot">•</span>
                                                <span class=""> Net Profit </span>
                                             </span>

                                          </td>
                                          <td class=""> 56777</td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="card cardd h-100">
                        <div class="card-body">
                           <div class="d-flex justify-content-between">
                              <div class="">
                                 <!-- <i class="fas fa-ellipsis-v"></i> -->
                                 <span>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="9" height="16" viewBox="0 0 9 16"
                                       fill="none">
                                       <path d="M3.53003 12.32H0.130005V15.19H3.53003V12.32Z" fill="#A7A7AC" />
                                       <path d="M8.29999 12.32H4.90002V15.19H8.29999V12.32Z" fill="#A7A7AC" />
                                       <path d="M3.56 8.34003H0.159973V11.21H3.56V8.34003Z" fill="#A7A7AC" />
                                       <path d="M8.33002 8.34003H4.92999V11.21H8.33002V8.34003Z" fill="#A7A7AC" />
                                       <path d="M3.56 4.45001H0.159973V7.32001H3.56V4.45001Z" fill="#A7A7AC" />
                                       <path d="M8.34003 4.45001H4.94V7.32001H8.34003V4.45001Z" fill="#A7A7AC" />
                                       <path d="M3.53003 0.469971H0.130005V3.34003H3.53003V0.469971Z" fill="#A7A7AC" />
                                       <path d="M8.29999 0.469971H4.90002V3.34003H8.29999V0.469971Z" fill="#A7A7AC" />
                                    </svg>
                                 </span>
                                 <span class="fst-normal textcolor" style="font-family: Roboto;">
                                    Pending Task
                                 </span>
                              </div>
                              <div class="">
                                 <span class="add py-0">ADD</span>
                              </div>
                           </div>
                           <hr />
                           <div class="">
                              <table class="table" style="font-family: Roboto;">
                                 <tbody>
                                    <tr>
                                       <td width="80%" class="text-left">
                                          <span class="d-flex">
                                             <span class="text-primary dot">•</span>
                                             <span class=""> Most Urgent </span>
                                          </span>

                                       </td>
                                       <td width="20%" class=""> 0000</td>
                                    </tr>
                                    <tr>
                                       <td class="text-left">
                                          <span class="d-flex">
                                             <span class="text-success dot">•</span>
                                             <span class=""> Urgent </span>
                                          </span>

                                       </td>
                                       <td class=""> 0000</td>
                                    </tr>
                                    <tr>
                                       <td class="text-left">
                                          <span class="d-flex">
                                             <span class="text-info dot">•</span>
                                             <span class=""> Normal </span>
                                          </span>

                                       </td>
                                       <td class=""> 0000</td>
                                    </tr>
                                    <tr>
                                       <td class="text-left">
                                          <span class="d-flex">
                                             <span class="text-warning dot">•</span>
                                             <span class=""> Task Satisfaction </span>
                                          </span>

                                       </td>
                                       <td class=""> 0000</td>
                                    </tr>
                                 </tbody>
                              </table>

                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- 2nd row end -->
               </div>
               <!-- 2nd container end-->
            </div>
            <!-- End of Main Content -->
         </div>
         <!-- End of Content Wrapper -->
      </div>
      <!-- End of Page Wrapper -->
      <!-- Scroll to Top Button-->
      <a class="scroll-to-top rounded" href="#page-top">
         <i class="fas fa-angle-up"></i>
      </a>

</body>

</html>