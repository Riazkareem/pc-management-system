<?php
session_start();
ob_start();
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

include 'db.php';
include 'crud_oop.php';
?>
<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css" />
<link
    href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
    rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@500&display=swap" rel="stylesheet">
<!-- Custom styles for this template-->
<link href="css/sb-admin-2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="style.css">
<link rel="shortcut icon" href="img/logo.png" type="image/x-icon">
<script type="text/javascript">
    window.onload = function () {
        var data = {
            labels: ["Unalocated", "Workshop"],
            datasets: [
                {
                    data: [60, 90],
                    backgroundColor: ["#5AC1FF", "#E9BD4E"],
                    hoverBackgroundColor: ["#5AC1FF", "#E9BD4E"],
                },
            ],
        };
        const sum = data.datasets[0].data.reduce((a, b) => a + b, 0);
        var promisedDeliveryChart = new Chart(
            document.getElementById("doughnutChart"),
            {
                type: "doughnut",
                data: data,
                options: {
                    cutoutPercentage: 70,
                    responsive: true,
                    legend: {
                        display: false,
                        position: "right", // Position the legend at the top
                        align: "right", // Center the legend horizontally
                        // fullWidth: true,
                        labels: {
                            usePointStyle: false,
                            boxWidth: 10,
                            fontColor: 'black',
                            fontSize: 31, // Adjust the font size as needed
                            fontFamily: "Roboto",
                        }
                    },
                },
            }
        );
        Chart.pluginService.register({
            beforeDraw: function (chart) {
                var width = chart.chart.width,
                    height = chart.chart.height,
                    ctx = chart.chart.ctx;
                ctx.restore();
                var fontSize = (height / 114).toFixed(2);
                ctx.font = fontSize + "em sans-serif";
                ctx.textBaseline = "middle";
                // var text = "75%",
                var text = sum,
                    textX = Math.round((width - ctx.measureText(text).width) / 2),
                    textY = height / 2;
                ctx.fillText(text, textX, textY);
                ctx.save();
            },
        });

        var data = {
            labels: ["Ebay", "Amazon"],
            datasets: [
                {
                    data: [60, 90],
                    backgroundColor: ["#5AC1FF", "#E9BD4E"],
                    hoverBackgroundColor: ["#5AC1FF", "#E9BD4E"],
                },
            ],
        };

        const sum2 = data.datasets[0].data.reduce((a, b) => a + b, 0);
        var promisedDeliveryChart = new Chart(
            document.getElementById("doughnutChart2"),
            {
                type: "doughnut",
                data: data,
                options: {
                    cutoutPercentage: 70,
                    responsive: true,
                    legend: {
                        display: false,
                        position: "right", // Position the legend at the top
                        align: "right", // Center the legend horizontally
                        // fullWidth: true,
                        labels: {
                            usePointStyle: false,
                            boxWidth: 10,
                            fontColor: 'black',
                            fontSize: 31, // Adjust the font size as needed
                            fontFamily: "Roboto",
                        }
                    },
                },
            }
        );
        Chart.pluginService.register({
            beforeDraw: function (chart) {
                var width = chart.chart.width,
                    height = chart.chart.height,
                    ctx = chart.chart.ctx;
                ctx.restore();
                var fontSize = (height / 114).toFixed(2);
                ctx.font = fontSize + "em sans-serif";
                ctx.textBaseline = "middle";
                // var text = "75%",
                var text = sum2,
                    textX = Math.round((width - ctx.measureText(text).width) / 2),
                    textY = height / 2;
                ctx.fillText(text, textX, textY);
                ctx.save();
            },
        });

    };
</script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.6/Chart.bundle.js"></script>
<script type="text/javascript" src="https://cdn.canvasjs.com/canvasjs.min.js"></script>