<div class="container-fluid bg-white  border-0 ">
    <!-- 1st Row -->
    <div class="row no-gutters" style="font-family: Roboto;">
        <!-- tab start -->
        <div class="col-md-2">
            <div class="card tabcolor my-1 mx-1 tabcard">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2 lineheight">
                            <div class="h5 mb-0 fst-normal text-white">
                                872
                            </div>
                            <div class="tabtext fst-normal text-white text-uppercase mb-2">
                                All Orders
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-shopping-cart fa-2x text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- tab end -->
        <!-- tab start -->
        <div class="col-md-2">
            <div class="card tab2 my-1 mx-1 tabcard">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2 lineheight">
                            <div class="h5 mb-0 fst-normal text-white">
                                285
                            </div>
                            <div class="tabtext fst-normal text-white text-uppercase mb-2">
                                Order Journey
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fa fa-sort fa-2x text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- tab end -->
        <!-- tab start -->
        <div class="col-md-2">
            <div class="card tab3 my-1 mx-1 tabcard">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2 lineheight">
                            <div class="h5 mb-0 fst-normal text-white">
                                53
                            </div>
                            <div class="tabtext fst-normal text-white text-uppercase mb-1">
                                Accounts
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-usd fa-2x text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- tab end -->
        <!-- tab start -->
        <div class="col-md-2">
            <div class="card tab4 my-1 mx-1 tabcard">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2 lineheight">
                            <div class="h5 mb-0 fst-normal text-white">
                                78
                            </div>
                            <div class="tabtext fst-normal text-white text-uppercase mb-1">
                                Inventory
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check fa-2x text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- tab end -->
        <!-- tab start -->
        <div class="col-md-2">
            <div class="card tab5 my-1 mx-1 tabcard">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2 lineheight">
                            <div class="h5 mb-0 fst-normal text-white">
                                78
                            </div>
                            <div class="tabtext fst-normal text-white text-uppercase mb-1">
                                Returns
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-refresh fa-2x text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- tab end -->
        <!-- tab start -->
        <div class="col-md-2">
            <div class="card tab6 my-1 mx-1 tabcard">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2 lineheight">
                            <div class="h5 mb-0 fst-normal text-white">
                                78
                            </div>
                            <div class="tabtext fst-normal text-white text-uppercase mb-1">
                                Pending Tasks
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-hourglass-half fa-2x text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- tab end -->
    </div>
    <!-- 1st Row end -->
</div>